-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 20 Mai 2019 à 00:47
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `strategy_planning_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `levier`
--

CREATE TABLE IF NOT EXISTS `levier` (
  `processus_id` int(11) NOT NULL,
  `objectif_id` int(11) NOT NULL,
  `programme_id` int(11) NOT NULL,
  UNIQUE KEY `processus_id` (`processus_id`,`objectif_id`,`programme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `objectif`
--

CREATE TABLE IF NOT EXISTS `objectif` (
  `objectif_id` int(11) NOT NULL AUTO_INCREMENT,
  `objectif_nom` varchar(255) NOT NULL,
  `objectif_desc` text NOT NULL,
  `objectif_indicateur` float NOT NULL,
  `strategie_id` int(11) NOT NULL,
  PRIMARY KEY (`objectif_id`),
  UNIQUE KEY `strategie_id` (`strategie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `organisation`
--

CREATE TABLE IF NOT EXISTS `organisation` (
  `organisation_id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_nom` varchar(255) NOT NULL,
  `organisation_desc` text NOT NULL,
  `organisation_adr` varchar(255) NOT NULL,
  `organisation_tel` varchar(255) NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  PRIMARY KEY (`organisation_id`),
  UNIQUE KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `processus`
--

CREATE TABLE IF NOT EXISTS `processus` (
  `processus_id` int(11) NOT NULL AUTO_INCREMENT,
  `processus_nom` varchar(255) NOT NULL,
  `processus_desc` text NOT NULL,
  `startegie_id` int(11) NOT NULL,
  PRIMARY KEY (`processus_id`),
  UNIQUE KEY `startegie_id` (`startegie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `programme`
--

CREATE TABLE IF NOT EXISTS `programme` (
  `programme_id` int(11) NOT NULL AUTO_INCREMENT,
  `programme_nom` varchar(255) NOT NULL,
  `programme_date_debut` date NOT NULL,
  `programme_date_fin` date NOT NULL,
  `programme_indicateur` float NOT NULL,
  `programme_coef` int(11) NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  PRIMARY KEY (`programme_id`),
  UNIQUE KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE IF NOT EXISTS `projet` (
  `projet_id` int(11) NOT NULL AUTO_INCREMENT,
  `projet_nom` varchar(255) NOT NULL,
  `projet_desc` text NOT NULL,
  `projet_date_debut` date NOT NULL,
  `projet_date_fin` date NOT NULL,
  `projet_indicateur` float NOT NULL,
  `projet_coef` int(11) NOT NULL,
  `utlisateur_id` int(11) NOT NULL,
  `programme_id` int(11) NOT NULL,
  PRIMARY KEY (`projet_id`),
  UNIQUE KEY `utlisateur_id` (`utlisateur_id`,`programme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `strategie`
--

CREATE TABLE IF NOT EXISTS `strategie` (
  `strategie_id` int(11) NOT NULL AUTO_INCREMENT,
  `strategie_nom` varchar(255) NOT NULL,
  `strategie_desc` text NOT NULL,
  `strategie_date_debut` date NOT NULL,
  `strategie_date_fin` date NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  `organisation_id` int(11) NOT NULL,
  PRIMARY KEY (`strategie_id`),
  UNIQUE KEY `utilisateur_id` (`utilisateur_id`,`organisation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `swot`
--

CREATE TABLE IF NOT EXISTS `swot` (
  `swot_id` int(11) NOT NULL AUTO_INCREMENT,
  `swot_s` text NOT NULL,
  `swot_w` text NOT NULL,
  `swot_o` text NOT NULL,
  `swot_t` text NOT NULL,
  `strategie_id` int(11) NOT NULL,
  PRIMARY KEY (`swot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `utilisateur_id` int(11) NOT NULL AUTO_INCREMENT,
  `utilisateur_nom` varchar(255) NOT NULL,
  `utilisateur_email` varchar(255) NOT NULL,
  `utilisateur_tel` varchar(255) NOT NULL,
  PRIMARY KEY (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
